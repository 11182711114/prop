package prop.assignment0;

import java.io.IOException;

public class Parser implements IParser {

	private Tokenizer tk = null;
	
	public Parser() {
	}
	
	@Override
	public void open(String fileName) throws IOException, TokenizerException {
		tk = new Tokenizer();
		tk.open(fileName);
		tk.moveNext();		
	}

	@Override
	public INode parse() throws IOException, TokenizerException, ParserException {
		if (tk == null) 
			throw new IOException("No open file");
	
		BlockNode bn = null;
		bn = new BlockNode(tk);
		
		return bn;
	}

	@Override
	public void close() throws IOException {
		tk.close();		
	}
	
}
