package prop.assignment0;

public class ArrayHolder {
	Object[] arr;
	
	public ArrayHolder(Object[] arr) {
		this.arr = arr;
	}
	
}
