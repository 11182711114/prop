package prop.assignment0;

public class ParserException extends Exception {
	public ParserException(String message) {
		super(message);
	}
}