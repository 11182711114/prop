package prop.assignment0;

public class TokenizerException extends Exception {
	public TokenizerException(String message) {
		super(message);
	}
}